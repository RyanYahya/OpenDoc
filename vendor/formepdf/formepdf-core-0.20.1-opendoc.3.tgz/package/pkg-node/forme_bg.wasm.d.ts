/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const certify_pdf: (a: number, b: number, c: number, d: number) => [number, number, number, number];
export const find_text_regions: (a: number, b: number, c: number, d: number) => [number, number, number, number];
export const merge_pdfs: (a: number, b: number) => [number, number, number, number];
export const redact_pdf: (a: number, b: number, c: number, d: number) => [number, number, number, number];
export const redact_text: (a: number, b: number, c: number, d: number) => [number, number, number, number];
export const render_pdf: (a: number, b: number) => [number, number, number, number];
export const render_pdf_with_layout: (a: number, b: number) => [number, number, number];
export const render_template_pdf: (a: number, b: number, c: number, d: number) => [number, number, number, number];
export const render_template_pdf_with_layout: (a: number, b: number, c: number, d: number) => [number, number, number];
export const init_panic_hook: () => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_start: () => void;
