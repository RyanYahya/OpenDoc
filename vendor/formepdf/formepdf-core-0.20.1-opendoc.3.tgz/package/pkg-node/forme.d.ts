/* tslint:disable */
/* eslint-disable */

/**
 * Certify PDF bytes with an X.509 certificate (PKCS#7 detached signature).
 */
export function certify_pdf(pdf_bytes: Uint8Array, config_json: string): Uint8Array;

/**
 * Find text regions matching patterns in a PDF.
 * Returns JSON string of Vec<RedactionRegion>.
 */
export function find_text_regions(pdf_bytes: Uint8Array, patterns_json: string): string;

export function init_panic_hook(): void;

/**
 * Merge multiple PDFs into a single document.
 * Accepts a JSON array of base64-encoded PDF strings.
 */
export function merge_pdfs(pdfs_json: string): Uint8Array;

/**
 * Redact regions of a PDF by overlaying opaque rectangles.
 */
export function redact_pdf(pdf_bytes: Uint8Array, redactions_json: string): Uint8Array;

/**
 * Redact text matching patterns from a PDF.
 */
export function redact_text(pdf_bytes: Uint8Array, patterns_json: string): Uint8Array;

export function render_pdf(json: string): Uint8Array;

export function render_pdf_with_layout(json: string): any;

export function render_template_pdf(template_json: string, data_json: string): Uint8Array;

export function render_template_pdf_with_layout(template_json: string, data_json: string): any;
