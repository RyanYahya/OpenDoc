/* tslint:disable */
/* eslint-disable */

/**
 * Certify PDF bytes with an X.509 certificate (PKCS#7 detached signature).
 */
export function certify_pdf(pdf_bytes: Uint8Array, config_json: string): Uint8Array;

/**
 * Find text regions matching patterns in a PDF.
 * Returns JSON string of Vec<RedactionRegion>.
 */
export function find_text_regions(pdf_bytes: Uint8Array, patterns_json: string): string;

export function init_panic_hook(): void;

/**
 * Merge multiple PDFs into a single document.
 * Accepts a JSON array of base64-encoded PDF strings.
 */
export function merge_pdfs(pdfs_json: string): Uint8Array;

/**
 * Redact regions of a PDF by overlaying opaque rectangles.
 */
export function redact_pdf(pdf_bytes: Uint8Array, redactions_json: string): Uint8Array;

/**
 * Redact text matching patterns from a PDF.
 */
export function redact_text(pdf_bytes: Uint8Array, patterns_json: string): Uint8Array;

export function render_pdf(json: string): Uint8Array;

export function render_pdf_with_layout(json: string): any;

export function render_template_pdf(template_json: string, data_json: string): Uint8Array;

export function render_template_pdf_with_layout(template_json: string, data_json: string): any;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly certify_pdf: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly find_text_regions: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly merge_pdfs: (a: number, b: number) => [number, number, number, number];
    readonly redact_pdf: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly redact_text: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly render_pdf: (a: number, b: number) => [number, number, number, number];
    readonly render_pdf_with_layout: (a: number, b: number) => [number, number, number];
    readonly render_template_pdf: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly render_template_pdf_with_layout: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly init_panic_hook: () => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
